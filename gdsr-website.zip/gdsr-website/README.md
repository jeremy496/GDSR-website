# Goldendoodle Stump Removal — website

A self-contained static site (plain HTML/CSS/JS, no build step) for
goldendoodlestumpremoval.com. Built to be hosted for free on GitHub Pages so
there's no vendor account that can delete your data again.

## What's in here

- `index.html` — the whole site (one page: hero, services & pricing, price
  calculator, about, contact/quote form, footer)
- `styles.css` — all styling
- `script.js` — mobile menu, the price calculator, and the contact form submit
- `images/` — your logo files, cropped and cleaned up:
  - `logo-badge.png` — the round mascot logo (header + hero)
  - `logo-wordmark.png` — the horizontal text logo (about + footer)
  - `favicon-32.png`, `favicon-192.png`, `favicon-512.png` — browser tab icon
- `CNAME` — tells GitHub Pages this site should answer to
  `goldendoodlestumpremoval.com`

## 1. Put it on GitHub (no command line needed)

1. Go to github.com, log in, click **New repository**.
2. Name it something like `gdsr-website`. Keep it **Public** (required for
   free GitHub Pages). Don't add a README/gitignore — just create it.
3. On the new repo's page, click **uploading an existing file**.
4. Drag in *every file and folder* from this folder (`index.html`,
   `styles.css`, `script.js`, `images/`, `CNAME`) and commit.

## 2. Turn on GitHub Pages

1. In the repo, go to **Settings → Pages**.
2. Under "Build and deployment", set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`. Save.
3. GitHub will give you a URL like `https://yourusername.github.io/gdsr-website/`
   — give it a minute or two, then check it loads.

## 3. Point your domain at it

You already own `goldendoodlestumpremoval.com`. At whoever you bought/manage
the domain through (GoDaddy, Namecheap, Google Domains, etc.), edit its DNS
records:

- Add an **A record** for `@` pointing to each of GitHub's IPs:
  `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
- Add a **CNAME record** for `www` pointing to `yourusername.github.io`

Then back in **Settings → Pages** on GitHub, type
`goldendoodlestumpremoval.com` into the custom domain box and save (this is
what the included `CNAME` file also does automatically once it's in the
repo). Check **Enforce HTTPS** once it's available — this fixes the "not
safe" warning the old site had.

DNS changes can take anywhere from a few minutes to a few hours to kick in.

## 4. Make the quote form actually send you email

The form in `index.html` posts to Formspree, a free service that turns a
plain HTML form into working email notifications — no backend required
(GitHub Pages can't run server code).

1. Go to formspree.io and make a free account with
   jeremy@goldendoodlestumpremoval.com.
2. Create a new form, copy the endpoint it gives you (looks like
   `https://formspree.io/f/abcdwxyz`).
3. In `index.html`, find this line (near the bottom, in the Contact section):
   `<form class="contact-form" id="quote-form" action="https://formspree.io/f/YOUR_FORM_ID" method="POST">`
   and replace `YOUR_FORM_ID` with your real endpoint.
4. Re-upload the changed `index.html` to GitHub (same drag-and-drop as
   before, or edit the file directly on github.com).

Until you do this, the form will show an error message — the phone/text/email
links above the form work immediately either way.

## 5. Content notes / things to double-check

- Pricing shown ($10/inch, $250 minimum, three tiers) comes from your
  Pricing Model note — double check the tier names and cleanup/mulch pricing
  match what you actually want to charge.
- Business phone used throughout: (509) 479-4685 (your GHL business line,
  not your personal cell, per your own note not to use the personal number
  on GDSR-facing material).
- License number shown: WA L&I Contractor #GOLDESR741MO.
- The old site's meta title used "Spokane & North Idaho" — since your notes
  say you're not currently licensed in Idaho, this version just says
  "Spokane, WA and the surrounding area." Update this (and the licensing)
  if that's changed.
- Add real job photos when you have them — drop new images into `images/`
  and reference them in `index.html`. The current art is just your logo.
