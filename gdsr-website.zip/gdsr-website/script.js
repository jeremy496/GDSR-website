// Goldendoodle Stump Removal — site behavior

document.getElementById('year').textContent = new Date().getFullYear();

// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const mobileNav = document.getElementById('mobile-nav');
if (navToggle && mobileNav) {
  navToggle.addEventListener('click', () => {
    const isOpen = mobileNav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
  mobileNav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileNav.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });
}

// Stump price calculator
// Formula: per-stump price = max($250 minimum, $10 x diameter in inches).
// Cleanup / Full Removal + Mulch tiers carry extra labor/disposal cost on top of the base grind;
// since exact tier surcharges aren't fixed publicly, we show a clearly-labeled illustrative
// range rather than a false-precision single number for those tiers.
const RATE_PER_INCH = 10;
const MINIMUM_PRICE = 250;
const TIER_MULTIPLIER = {
  basic: 1,
  cleanup: 1.15,
  full: 1.35
};
const TIER_LABEL = {
  basic: 'Basic Grind',
  cleanup: 'Grind + Cleanup',
  full: 'Full Removal + Mulch'
};

const diameterInput = document.getElementById('diameter');
const countInput = document.getElementById('count');
const tierSelect = document.getElementById('tier');
const calcOutput = document.getElementById('calc-output');
const calcNote = document.getElementById('calc-note');

function formatCurrency(n) {
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
}

function updateEstimate() {
  const diameter = Math.max(1, parseInt(diameterInput.value, 10) || 0);
  const count = Math.max(1, parseInt(countInput.value, 10) || 1);
  const tier = tierSelect.value;
  const multiplier = TIER_MULTIPLIER[tier] ?? 1;

  const perStumpBase = Math.max(MINIMUM_PRICE, RATE_PER_INCH * diameter);
  const perStumpEstimate = Math.round(perStumpBase * multiplier);
  const total = perStumpEstimate * count;

  calcOutput.textContent = formatCurrency(total);
  calcNote.textContent =
    `${TIER_LABEL[tier]} · ${count} stump${count > 1 ? 's' : ''} at ~${diameter}" · ` +
    `based on $10/inch, $250 minimum per stump. This is a starting estimate — your exact price is confirmed on-site.`;
}

[diameterInput, countInput, tierSelect].forEach(el => {
  if (el) el.addEventListener('input', updateEstimate);
});
updateEstimate();

// Keep the "interested in" tier on the contact form in sync when arriving from the calculator CTA
const calcForm = document.getElementById('calc-form');
const tierSelectField = document.getElementById('tier-select');
const stumpsField = document.getElementById('stumps');
if (calcForm) {
  calcForm.addEventListener('submit', (e) => e.preventDefault());
  const calcCta = calcForm.querySelector('.calc-cta');
  if (calcCta) {
    calcCta.addEventListener('click', () => {
      if (tierSelectField) tierSelectField.value = tierSelect.value;
      if (stumpsField) stumpsField.value = countInput.value;
    });
  }
}

// Contact form submission (Formspree-compatible: works with any endpoint that accepts
// a normal POST and responds to fetch — swap the form's `action` in index.html to your
// own Formspree endpoint after creating a free account at formspree.io)
const quoteForm = document.getElementById('quote-form');
if (quoteForm) {
  quoteForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = quoteForm.querySelector('.form-submit');
    const originalLabel = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending…';

    const existingMsg = quoteForm.querySelector('.form-success, .form-error');
    if (existingMsg) existingMsg.remove();

    try {
      const response = await fetch(quoteForm.action, {
        method: 'POST',
        body: new FormData(quoteForm),
        headers: { Accept: 'application/json' }
      });

      const msg = document.createElement('p');
      if (response.ok) {
        msg.className = 'form-success';
        msg.textContent = "Thanks! Your quote request is in — I'll get back to you shortly.";
        quoteForm.reset();
        updateEstimate();
      } else {
        msg.className = 'form-error';
        msg.textContent = "That didn't go through. Please call or text (509) 479-4685 instead.";
      }
      quoteForm.appendChild(msg);
    } catch (err) {
      const msg = document.createElement('p');
      msg.className = 'form-error';
      msg.textContent = "That didn't go through. Please call or text (509) 479-4685 instead.";
      quoteForm.appendChild(msg);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalLabel;
    }
  });
}
